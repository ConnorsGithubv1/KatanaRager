# TileThumbnailMaker
Making Tiles from Grid data and save as png

Run this python script to load multiple images as thumbnails and put into a single image in a grid pattern.

## Requirements
Run *pip install Pillow* to install Pillow library dependencies
